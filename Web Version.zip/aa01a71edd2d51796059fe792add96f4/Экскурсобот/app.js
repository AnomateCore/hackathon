// app.js - Полностью рабочая версия без опечаток
document.addEventListener('DOMContentLoaded', () => {
    const state = {
        currentSection: 'home',
        currentCategory: null,
        currentCityId: 1
    };

    const sections = document.querySelectorAll('.section');
    const navItems = document.querySelectorAll('.nav-menu li');
    const themeToggle = document.getElementById('theme-toggle');
    const rootCategories = document.getElementById('root-categories');
    const subCategories = document.getElementById('sub-categories');
    const itemsList = document.getElementById('items-list');
    const backBtn = document.getElementById('back-btn');
    const breadcrumbs = document.getElementById('breadcrumbs');

    // 🔹 Универсальный API-запрос
    async function apiCall(action, params = {}) {
        const formData = new FormData();
        formData.append('action', action);
        formData.append('city_id', state.currentCityId);
        Object.entries(params).forEach(([k, v]) => formData.append(k, v));

        try {
            const res = await fetch('index.php', { method: 'POST', body: formData, cache: 'no-store' });
            const text = await res.text();
            const json = JSON.parse(text);
            if (!json.success) throw new Error(json.error || 'API error');
            return json.data;
        } catch (e) {
            console.error('❌ API Error:', e);
            throw e;
        }
    }

    // 🔹 Переключение секций
    function showSection(sectionId) {
        sections.forEach(s => s.classList.remove('active'));
        const target = document.getElementById(sectionId);
        if (target) target.classList.add('active');
        
        navItems.forEach(li => {
            li.classList.toggle('active', li.dataset.section === sectionId);
        });
        
        state.currentSection = sectionId;
        
        if (sectionId === 'attractions') {
            loadRootCategories();
        } else if (sectionId === 'news') {
            loadNews();
        } else if (sectionId === 'media') {
            loadMedia();
        } else if (sectionId === 'facts') {
            loadFact();
        }
    }

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            showSection(item.dataset.section);
        });
    });

    document.querySelectorAll('[data-action]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const action = e.currentTarget.dataset.action;
            if (action) showSection(action);
        });
    });

    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            document.body.classList.toggle('light-theme');
            document.body.classList.toggle('dark-theme');
            const isDark = document.body.classList.contains('dark-theme');
            themeToggle.textContent = isDark ? '🌙 Тёмная тема' : '☀️ Светлая тема';
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
        });

        if (localStorage.getItem('theme') === 'light') {
            document.body.classList.replace('dark-theme', 'light-theme');
            themeToggle.textContent = '☀️ Светлая тема';
        }
    }

    // 🔹 Загрузка корневых категорий (Достопримечательности, Развлечения)
    async function loadRootCategories() {
        if (!rootCategories) return;
        try {
            const data = await apiCall('get_categories'); // parent_id = null по умолчанию
            
            if (Array.isArray(data) && data.length > 0) {
                rootCategories.innerHTML = data.map(cat => `
                    <div class="category-card" data-id="${cat.id}" data-name="${cat.name}">
                        <div class="icon">${cat.icon || '📁'}</div>
                        <div>${cat.name}</div>
                    </div>
                `).join('');
                
                rootCategories.classList.remove('hidden');
                subCategories.classList.add('hidden');
                itemsList.classList.add('hidden');
                backBtn.classList.add('hidden');
                breadcrumbs.innerHTML = '';
                
                document.querySelectorAll('#root-categories .category-card').forEach(card => {
                    card.addEventListener('click', () => loadSubCategories(card.dataset.id, card.dataset.name));
                });
            } else {
                rootCategories.innerHTML = '<p>😕 Категории не найдены</p>';
            }
        } catch (err) {
            rootCategories.innerHTML = `<p>❌ Не удалось загрузить: ${err.message}</p>`;
        }
    }

    // 🔹 Загрузка подкатегорий (Церкви, Парки...)
    async function loadSubCategories(parentId, parentName) {
        if (!subCategories) return;
        try {
            const data = await apiCall('get_categories', { parent_id: parentId });
            
            if (Array.isArray(data) && data.length > 0) {
                subCategories.innerHTML = data.map(cat => `
                    <div class="category-card" data-id="${cat.id}" data-name="${cat.name}">
                        <div class="icon">${cat.icon || '📁'}</div>
                        <div>${cat.name}</div>
                    </div>
                `).join('');
                
                rootCategories.classList.add('hidden');
                subCategories.classList.remove('hidden');
                itemsList.classList.add('hidden');
                backBtn.classList.remove('hidden');
                breadcrumbs.innerHTML = `<span onclick="loadRootCategories()" style="cursor:pointer;color:var(--accent)">Категории</span> / <strong>${parentName}</strong>`;
                
                document.querySelectorAll('#sub-categories .category-card').forEach(card => {
                    card.addEventListener('click', () => loadItems(card.dataset.id, card.dataset.name));
                });
            } else {
                // Если подкатегорий нет, сразу грузим элементы этого раздела
                loadItems(parentId, parentName);
            }
        } catch (err) {
            subCategories.innerHTML = `<p>❌ Не удалось загрузить: ${err.message}</p>`;
        }
    }

    // 🔹 Загрузка элементов (Карточки)
    async function loadItems(categoryId, categoryName) {
        if (!itemsList) return;
        try {
            const data = await apiCall('get_items', { category_id: categoryId });
            
            if (Array.isArray(data) && data.length > 0) {
                itemsList.innerHTML = data.map(item => `
                    <div class="item-card" data-id="${item.id}">
                        ${item.image_url ? `<img src="${item.image_url}" alt="${item.title}" onerror="this.style.display='none'">` : ''}
                        <h3>${item.title}</h3>
                        <p>${item.description ? item.description.substring(0, 100) + (item.description.length > 100 ? '...' : '') : ''}</p>
                        ${item.address ? `<small>📍 ${item.address}</small>` : ''}
                        ${item.latitude && item.longitude ? `<button class="btn-secondary show-map-btn" data-lat="${item.latitude}" data-lon="${item.longitude}" data-title="${item.title.replace(/"/g, '&quot;')}">🗺️ Карта</button>` : ''}
                    </div>
                `).join('');
                
                subCategories.classList.add('hidden');
                itemsList.classList.remove('hidden');
                backBtn.classList.remove('hidden');
                breadcrumbs.innerHTML += ` / <strong>${categoryName}</strong>`;
                
                // Обработчики кликов
                document.querySelectorAll('.item-card').forEach(card => {
                    card.addEventListener('click', (e) => {
                        if (e.target.classList.contains('show-map-btn')) return;
                        const item = data.find(i => i.id == card.dataset.id);
                        if (item && typeof openModal === 'function') {
                            openModal(`
                                <h2>${item.title}</h2>
                                ${item.image_url ? `<img src="${item.image_url}" style="max-width:100%;border-radius:8px;margin:1rem 0;">` : ''}
                                <p>${item.description || 'Нет описания'}</p>
                                ${item.address ? `<p><strong>📍 Адрес:</strong> ${item.address}</p>` : ''}
                                ${item.latitude && item.longitude ? `
                                    <div id="yandex-map"></div>
                                    <button class="map-btn" onclick="window.openInYandexMaps(${item.latitude}, ${item.longitude}, '${item.title.replace(/'/g, "\\'")}')">📍 Открыть в картах</button>
                                ` : ''}
                            `, { 
                                latitude: item.latitude ? parseFloat(item.latitude) : null, 
                                longitude: item.longitude ? parseFloat(item.longitude) : null, 
                                title: item.title 
                            });
                        }
                    });
                });
            } else {
                itemsList.innerHTML = '<p>😕 В этой категории пока нет записей</p>';
            }
        } catch (err) {
            itemsList.innerHTML = `<p>❌ Не удалось загрузить: ${err.message}</p>`;
        }
    }

    // 🔹 Кнопка "Назад"
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            if (itemsList.classList.contains('hidden') === false) {
                // Если мы смотрим список элементов -> назад к подкатегориям
                itemsList.classList.add('hidden');
                subCategories.classList.remove('hidden');
            } else if (subCategories.classList.contains('hidden') === false) {
                // Если мы смотрим подкатегории -> назад к корням
                subCategories.classList.add('hidden');
                rootCategories.classList.remove('hidden');
                breadcrumbs.innerHTML = '';
            }
        });
    }

    // 🔹 Новости
    async function loadNews() {
        const container = document.getElementById('news-list');
        if (!container) return;
        try {
            const data = await apiCall('get_news');
            container.innerHTML = Array.isArray(data) && data.length > 0 
                ? data.map(n => `<div class="news-card"><h3>${n.title}</h3><p>${n.content}</p>${n.source_url ? `<a href="${n.source_url}" target="_blank" style="color:var(--accent)">Источник →</a>` : ''}</div>`).join('')
                : '<p>📭 Новостей нет</p>';
        } catch (err) {
            container.innerHTML = `<p>❌ ${err.message}</p>`;
        }
    }

    // 🔹 Медиа
    async function loadMedia() {
        const container = document.getElementById('media-card');
        if (!container) return;
        try {
            const m = await apiCall('get_media');
            container.innerHTML = m && m.title 
                ? `<div class="item-card"><h3>${m.title}</h3>${m.poster_url ? `<img src="${m.poster_url}" style="max-width:100%;border-radius:8px;margin:1rem 0;">` : ''}<p>${m.description || ''}</p>${m.link_url ? `<a href="${m.link_url}" target="_blank" style="color:var(--accent)">Смотреть →</a>` : ''}</div>`
                : '<p>🎬 Нет рекомендаций</p>';
        } catch (err) {
            container.innerHTML = `<p>❌ ${err.message}</p>`;
        }
    }
    document.getElementById('new-media-btn')?.addEventListener('click', loadMedia);

    // 🔹 Факты
    async function loadFact() {
        const container = document.getElementById('fact-display');
        if (!container) return;
        try {
            const f = await apiCall('get_fact');
            container.innerHTML = f && f.content 
                ? `<span class="fact-icon">💡</span><p>${f.content}</p>` 
                : '<p>🤔 Фактов нет</p>';
        } catch (err) {
            container.innerHTML = `<p>❌ ${err.message}</p>`;
        }
    }
    document.getElementById('new-fact-btn')?.addEventListener('click', loadFact);

    // 🔹 Смена города
    window.addEventListener('city:change', (e) => {
        state.currentCityId = e.detail.id;
        console.log(`🏙️ Город: ${e.detail.name}`);
        if (state.currentSection === 'attractions') loadRootCategories();
        else if (state.currentSection === 'news') loadNews();
        else if (state.currentSection === 'facts') loadFact();
    });

    showSection('home');
});