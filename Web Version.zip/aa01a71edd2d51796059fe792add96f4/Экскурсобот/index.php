<?php
// 🔇 Отключаем вывод ошибок в браузер, чтобы PHP-уведомления не ломали JSON
ini_set('display_errors', 0);
error_reporting(E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR);
session_start();
require_once 'config.php';
$pdo = getPDO();
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
$action = $_POST['action'];
try {
switch ($action) {
case 'get_cities':
$stmt = $pdo->query("SELECT id, name, slug FROM cities ORDER BY name");
echo json_encode(['success' => true, 'data' => $stmt->fetchAll()], JSON_UNESCAPED_UNICODE);
break;
case 'get_categories':
$parentId = $_POST['parent_id'] ?? null;
// Категории обычно общие для всех городов, но проверка parent_id сделана устойчивой
$sql = "SELECT id, name, slug, icon, parent_id FROM categories WHERE is_active = 1";
$params = [];
if ($parentId !== null && is_numeric($parentId)) {
$sql .= " AND parent_id = ?";
$params[] = (int)$parentId;
} else {
// Принимаем и NULL, и 0 как признак корневого элемента
$sql .= " AND (parent_id IS NULL OR parent_id = 0)";
}
$sql .= " ORDER BY sort_order, name";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
echo json_encode(['success' => true, 'data' => $stmt->fetchAll()], JSON_UNESCAPED_UNICODE);
break;
case 'get_items':
$catId = $_POST['category_id'] ?? null;
$cityId = (int)($_POST['city_id'] ?? 1); // 🔥 Берём город!
$sql = "SELECT id, title, description, image_url, address, latitude, longitude, category_id
FROM attractions WHERE is_active = 1 AND city_id = ?"; // 🔥 Фильтр по городу
$params = [$cityId];
if ($catId && is_numeric($catId)) {
$sql .= " AND category_id = ?";
$params[] = (int)$catId;
}
$sql .= " ORDER BY title";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
echo json_encode(['success' => true, 'data' => $stmt->fetchAll()], JSON_UNESCAPED_UNICODE);
break;
case 'get_news':
$stmt = $pdo->query("SELECT title, content, image_url, source_url, published_at FROM news ORDER BY published_at DESC LIMIT 20");
echo json_encode(['success' => true, 'data' => $stmt->fetchAll()], JSON_UNESCAPED_UNICODE);
break;
case 'get_fact':
$stmt = $pdo->query("SELECT content FROM facts WHERE is_active = 1 ORDER BY RAND() LIMIT 1");
echo json_encode(['success' => true, 'data' => $stmt->fetch()], JSON_UNESCAPED_UNICODE);
break;
case 'get_media':
$stmt = $pdo->query("SELECT title, description, poster_url, link_url, rating FROM media WHERE is_active = 1 ORDER BY RAND() LIMIT 1");
echo json_encode(['success' => true, 'data' => $stmt->fetch()], JSON_UNESCAPED_UNICODE);
break;
default:
http_response_code(400);
echo json_encode(['success' => false, 'error' => 'Неизвестный метод']);
}
} catch (Exception $e) {
http_response_code(500);
echo json_encode(['success' => false, 'error' => 'Ошибка: ' . $e->getMessage()]);
}
exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>🗺️ Путеводитель</title>
<script src="https://api-maps.yandex.ru/2.1/?apikey=demo&lang=ru_RU" type="text/javascript"></script>
<style>
:root {
    --bg: #0f0f0f;
    --bg-secondary: #1a1a1a;
    --bg-tertiary: #252525;
    --bg-card: #1e1e1e;
    --text-primary: #ffffff;
    --text-secondary: #b0b0b0;
    --text-muted: #808080;
    --accent: #ff4757;
    --accent-hover: #ff6b7a;
    --accent-glow: rgba(255, 71, 87, 0.3);
    --border: #2a2a2a;
    --border-light: #333333;
    --success: #2ed573;
    --shadow-sm: 0 2px 8px rgba(0,0,0,0.3);
    --shadow-md: 0 4px 16px rgba(0,0,0,0.4);
    --shadow-lg: 0 8px 32px rgba(0,0,0,0.5);
    --radius-sm: 8px;
    --radius-md: 12px;
    --radius-lg: 16px;
    --radius-xl: 20px;
    --sidebar-width: 280px;
    --header-height: 70px;
    --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.light-theme {
    --bg: #f5f5f5;
    --bg-secondary: #ffffff;
    --bg-tertiary: #e8e8e8;
    --bg-card: #ffffff;
    --text-primary: #1a1a1a;
    --text-secondary: #666666;
    --text-muted: #999999;
    --border: #e0e0e0;
    --border-light: #d0d0d0;
    --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
    --shadow-md: 0 4px 16px rgba(0,0,0,0.12);
    --shadow-lg: 0 8px 32px rgba(0,0,0,0.15);
}

* { 
    box-sizing: border-box; 
    margin: 0; 
    padding: 0; 
    -webkit-tap-highlight-color: transparent;
}

html {
    scroll-behavior: smooth;
}

body { 
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; 
    background: var(--bg); 
    color: var(--text-primary); 
    line-height: 1.6; 
    overflow-x: hidden;
    font-size: 16px;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.app-container { 
    display: flex; 
    min-height: 100vh; 
}

/* Sidebar Styles */
.sidebar { 
    width: var(--sidebar-width); 
    background: var(--bg-secondary); 
    padding: 0;
    position: fixed; 
    height: 100vh; 
    overflow-y: auto; 
    overflow-x: hidden;
    z-index: 100; 
    transition: var(--transition);
    border-right: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    scrollbar-width: thin;
    scrollbar-color: var(--border-light) transparent;
}

.sidebar::-webkit-scrollbar {
    width: 6px;
}

.sidebar::-webkit-scrollbar-track {
    background: transparent;
}

.sidebar::-webkit-scrollbar-thumb {
    background: var(--border-light);
    border-radius: 3px;
}

.sidebar::-webkit-scrollbar-thumb:hover {
    background: var(--text-muted);
}

.logo { 
    font-size: 1.6rem; 
    font-weight: 800; 
    padding: 24px 20px; 
    background: linear-gradient(135deg, var(--accent) 0%, #ff6b7a 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    border-bottom: 1px solid var(--border);
    letter-spacing: -0.5px;
}

.sidebar-content {
    flex: 1;
    padding: 20px;
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.city-selector { 
    margin: 0;
}

.city-selector label { 
    display: block; 
    margin-bottom: 8px; 
    font-size: 0.8rem; 
    font-weight: 600;
    color: var(--text-secondary); 
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.custom-city-dropdown { 
    position: relative; 
    width: 100%; 
}

.city-search-box { 
    display: flex; 
    align-items: center; 
    background: var(--bg-tertiary); 
    border: 2px solid var(--border); 
    border-radius: var(--radius-md); 
    padding: 12px 14px; 
    cursor: pointer; 
    transition: var(--transition);
    gap: 10px;
}

.city-search-box:hover,
.city-search-box:focus-within {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px var(--accent-glow);
}

.city-search-box input { 
    flex: 1; 
    background: transparent; 
    border: none; 
    color: var(--text-primary); 
    outline: none; 
    font-size: 0.95rem;
    font-weight: 500;
}

.city-search-box input::placeholder {
    color: var(--text-muted);
}

.city-toggle { 
    background: none; 
    border: none; 
    color: var(--text-secondary); 
    cursor: pointer;
    font-size: 0.8rem;
    transition: var(--transition);
    padding: 4px;
}

.city-toggle:hover {
    color: var(--accent);
    transform: rotate(180deg);
}

.city-options { 
    position: absolute; 
    top: calc(100% + 6px); 
    left: 0; 
    right: 0; 
    background: var(--bg-tertiary); 
    border: 2px solid var(--border); 
    border-radius: var(--radius-md); 
    max-height: 240px; 
    overflow-y: auto; 
    z-index: 50; 
    list-style: none; 
    display: none;
    box-shadow: var(--shadow-lg);
    animation: slideDown 0.2s ease-out;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.city-options.show { 
    display: block; 
}

.city-options li { 
    padding: 12px 16px; 
    cursor: pointer; 
    border-bottom: 1px solid var(--border);
    transition: var(--transition);
    font-size: 0.95rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.city-options li::before {
    content: '📍';
    font-size: 1rem;
}

.city-options li:hover { 
    background: var(--accent); 
    color: #fff; 
    padding-left: 20px;
}

.city-options li.selected { 
    background: var(--accent); 
    color: #fff;
    font-weight: 600;
}

.city-options li.selected::before {
    content: '✅';
}

.city-options li:last-child { 
    border-bottom: none; 
}

/* Navigation Menu */
.nav-menu { 
    list-style: none; 
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.nav-menu li { 
    padding: 14px 16px; 
    border-radius: var(--radius-md); 
    cursor: pointer; 
    transition: var(--transition);
    font-weight: 500;
    font-size: 0.95rem;
    display: flex;
    align-items: center;
    gap: 12px;
    position: relative;
    overflow: hidden;
}

.nav-menu li::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
    background: var(--accent);
    transform: scaleY(0);
    transition: transform 0.3s ease;
}

.nav-menu li:hover { 
    background: var(--bg-tertiary);
    transform: translateX(4px);
}

.nav-menu li.active { 
    background: linear-gradient(135deg, var(--accent) 0%, var(--accent-hover) 100%);
    color: #fff;
    box-shadow: 0 4px 12px var(--accent-glow);
}

.nav-menu li.active::before {
    transform: scaleY(1);
}

.nav-menu li:hover:not(.active) {
    color: var(--accent);
}

/* Theme Button */
.theme-btn { 
    width: 100%; 
    padding: 14px; 
    background: var(--bg-tertiary); 
    border: 2px solid var(--border); 
    color: var(--text-primary); 
    border-radius: var(--radius-md); 
    cursor: pointer; 
    font-weight: 600;
    font-size: 0.95rem;
    transition: var(--transition);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-top: auto;
}

.theme-btn:hover { 
    background: var(--accent);
    border-color: var(--accent);
    color: #fff;
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
}

.theme-btn:active {
    transform: translateY(0);
}

/* Content Area */
.content { 
    flex: 1; 
    margin-left: var(--sidebar-width); 
    padding: 30px;
    min-height: 100vh;
    background: var(--bg);
}

.section { 
    display: none;
    animation: fadeIn 0.4s ease-out;
}

@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.section.active { 
    display: block; 
}

h1 { 
    font-size: 2.2rem; 
    margin-bottom: 24px;
    font-weight: 800;
    background: linear-gradient(135deg, var(--text-primary) 0%, var(--accent) 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    letter-spacing: -1px;
}

h2 { 
    font-size: 1.6rem; 
    margin-bottom: 20px;
    font-weight: 700;
    color: var(--text-primary);
}

/* Breadcrumbs */
#breadcrumbs {
    padding: 12px 16px;
    background: var(--bg-secondary);
    border-radius: var(--radius-md);
    margin-bottom: 20px;
    font-size: 0.9rem;
    border: 1px solid var(--border);
}

#breadcrumbs span {
    cursor: pointer;
    transition: var(--transition);
}

#breadcrumbs span:hover {
    color: var(--accent);
    text-decoration: underline;
}

/* Grids */
.categories-grid, 
.items-grid { 
    display: grid; 
    grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); 
    gap: 20px; 
    margin: 20px 0; 
}

/* Category Card */
.category-card { 
    background: var(--bg-card); 
    padding: 24px; 
    border-radius: var(--radius-lg); 
    cursor: pointer; 
    transition: var(--transition);
    border: 2px solid var(--border);
    text-align: center;
    position: relative;
    overflow: hidden;
}

.category-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, var(--accent) 0%, var(--accent-hover) 100%);
    opacity: 0;
    transition: opacity 0.3s ease;
    z-index: 0;
}

.category-card:hover { 
    transform: translateY(-6px);
    border-color: var(--accent);
    box-shadow: var(--shadow-lg);
}

.category-card:hover::before {
    opacity: 0.05;
}

.category-card > * {
    position: relative;
    z-index: 1;
}

.category-card .icon { 
    font-size: 3rem; 
    margin-bottom: 12px;
    display: block;
    transition: var(--transition);
}

.category-card:hover .icon {
    transform: scale(1.1);
}

.category-card div:last-child {
    font-weight: 600;
    font-size: 1.05rem;
    color: var(--text-primary);
}

/* Item Card */
.item-card { 
    background: var(--bg-card); 
    border-radius: var(--radius-lg); 
    cursor: pointer; 
    transition: var(--transition);
    border: 2px solid var(--border);
    overflow: hidden;
    display: flex;
    flex-direction: column;
    height: 100%;
}

.item-card:hover { 
    transform: translateY(-6px);
    border-color: var(--accent);
    box-shadow: var(--shadow-lg);
}

.item-card img { 
    width: 100%; 
    height: 180px; 
    object-fit: cover; 
    transition: var(--transition);
}

.item-card:hover img {
    transform: scale(1.05);
}

.item-card-content {
    padding: 18px;
    flex: 1;
    display: flex;
    flex-direction: column;
}

.item-card h3 { 
    font-size: 1.15rem; 
    margin-bottom: 8px;
    font-weight: 700;
    line-height: 1.3;
}

.item-card p { 
    font-size: 0.9rem; 
    color: var(--text-secondary); 
    margin-bottom: 12px;
    line-height: 1.5;
    flex: 1;
}

.item-card small { 
    display: flex;
    align-items: center;
    gap: 6px;
    color: var(--accent); 
    font-size: 0.85rem; 
    font-weight: 500;
    margin-bottom: 12px;
}

.btn-secondary {
    width: 100%;
    padding: 10px 16px;
    background: var(--bg-tertiary);
    color: var(--text-primary);
    border: 2px solid var(--border);
    border-radius: var(--radius-sm);
    cursor: pointer;
    font-weight: 600;
    font-size: 0.9rem;
    transition: var(--transition);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.btn-secondary:hover {
    background: var(--accent);
    border-color: var(--accent);
    color: #fff;
    transform: translateY(-2px);
}

/* Back Button */
.btn-back { 
    margin: 20px 0; 
    padding: 12px 24px; 
    background: var(--bg-tertiary); 
    color: var(--text-primary); 
    border: 2px solid var(--border); 
    border-radius: var(--radius-md); 
    cursor: pointer;
    font-weight: 600;
    font-size: 0.95rem;
    transition: var(--transition);
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.btn-back:hover { 
    background: var(--accent);
    border-color: var(--accent);
    color: #fff;
    transform: translateX(-4px);
}

.hidden { 
    display: none !important; 
}

/* Fact Box */
.fact-box { 
    background: linear-gradient(135deg, var(--bg-card) 0%, var(--bg-secondary) 100%);
    padding: 32px; 
    border-radius: var(--radius-xl); 
    margin: 20px 0; 
    text-align: center;
    border: 2px solid var(--border);
    box-shadow: var(--shadow-md);
}

.fact-icon { 
    font-size: 3.5rem; 
    display: block; 
    margin-bottom: 16px;
    animation: bounce 2s infinite;
}

@keyframes bounce {
    0%, 20%, 50%, 80%, 100% {
        transform: translateY(0);
    }
    40% {
        transform: translateY(-10px);
    }
    60% {
        transform: translateY(-5px);
    }
}

.fact-box p {
    font-size: 1.1rem;
    line-height: 1.7;
    color: var(--text-primary);
}

/* News Card */
.news-card { 
    background: var(--bg-card); 
    padding: 24px; 
    border-radius: var(--radius-lg);
    margin-bottom: 20px;
    border: 2px solid var(--border);
    transition: var(--transition);
}

.news-card:hover {
    border-color: var(--accent);
    transform: translateX(4px);
}

.news-card h3 {
    font-size: 1.2rem;
    margin-bottom: 12px;
    font-weight: 700;
}

.news-card p {
    color: var(--text-secondary);
    line-height: 1.6;
    margin-bottom: 12px;
}

.news-card a {
    color: var(--accent);
    text-decoration: none;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: var(--transition);
}

.news-card a:hover {
    color: var(--accent-hover);
    gap: 10px;
}

/* Modal */
.modal-overlay { 
    position: fixed; 
    top: 0; 
    left: 0; 
    right: 0; 
    bottom: 0; 
    background: rgba(0,0,0,0.85); 
    backdrop-filter: blur(8px);
    display: flex; 
    align-items: center; 
    justify-content: center; 
    z-index: 1000; 
    padding: 20px;
    opacity: 0;
    visibility: hidden;
    transition: var(--transition);
}

.modal-overlay:not(.hidden) {
    opacity: 1;
    visibility: visible;
}

.modal-box { 
    background: var(--bg-secondary); 
    padding: 0;
    border-radius: var(--radius-xl); 
    max-width: 600px; 
    width: 100%; 
    max-height: 90vh; 
    overflow-y: auto; 
    position: relative;
    box-shadow: var(--shadow-lg);
    transform: scale(0.9);
    transition: transform 0.3s ease;
    border: 2px solid var(--border);
}

.modal-overlay:not(.hidden) .modal-box {
    transform: scale(1);
}

.modal-box::-webkit-scrollbar {
    width: 8px;
}

.modal-box::-webkit-scrollbar-track {
    background: var(--bg-tertiary);
    border-radius: 4px;
}

.modal-box::-webkit-scrollbar-thumb {
    background: var(--border-light);
    border-radius: 4px;
}

.modal-close { 
    position: absolute; 
    top: 16px; 
    right: 16px; 
    background: var(--bg-tertiary); 
    border: none; 
    color: var(--text-primary); 
    font-size: 1.5rem; 
    cursor: pointer;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: var(--transition);
    z-index: 10;
}

.modal-close:hover { 
    background: var(--accent);
    color: #fff;
    transform: rotate(90deg);
}

.modal-content {
    padding: 24px;
}

.modal-content h2 {
    margin-bottom: 16px;
    padding-right: 50px;
}

.modal-content img {
    width: 100%;
    border-radius: var(--radius-md);
    margin: 16px 0;
}

.modal-content p {
    line-height: 1.7;
    color: var(--text-secondary);
    margin-bottom: 12px;
}

/* Mobile Toggle */
.mobile-toggle { 
    display: none; 
    position: fixed; 
    top: 16px; 
    left: 16px; 
    z-index: 200; 
    background: var(--accent); 
    color: #fff; 
    border: none; 
    padding: 12px 16px; 
    border-radius: var(--radius-md); 
    cursor: pointer;
    font-size: 1.2rem;
    box-shadow: var(--shadow-md);
    transition: var(--transition);
}

.mobile-toggle:hover {
    background: var(--accent-hover);
    transform: scale(1.05);
}

/* Map */
#yandex-map { 
    width: 100%; 
    height: 300px; 
    border-radius: var(--radius-md); 
    margin: 16px 0;
    border: 2px solid var(--border);
}

.map-btn { 
    margin-top: 12px; 
    width: 100%; 
    padding: 14px; 
    background: linear-gradient(135deg, var(--accent) 0%, var(--accent-hover) 100%);
    color: #fff; 
    border: none; 
    border-radius: var(--radius-md); 
    cursor: pointer;
    font-weight: 600;
    font-size: 1rem;
    transition: var(--transition);
    box-shadow: 0 4px 12px var(--accent-glow);
}

.map-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px var(--accent-glow);
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 60px 20px;
    color: var(--text-muted);
}

.empty-state-icon {
    font-size: 4rem;
    margin-bottom: 16px;
    opacity: 0.5;
}

/* Loading Animation */
@keyframes shimmer {
    0% {
        background-position: -1000px 0;
    }
    100% {
        background-position: 1000px 0;
    }
}

.loading {
    background: linear-gradient(90deg, var(--bg-tertiary) 0%, var(--bg-card) 50%, var(--bg-tertiary) 100%);
    background-size: 1000px 100%;
    animation: shimmer 2s infinite;
}

/* Responsive Design */
@media (max-width: 1024px) {
    .categories-grid,
    .items-grid {
        grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
        gap: 16px;
    }
}

@media (max-width: 768px) {
    :root {
        --sidebar-width: 100%;
    }
    
    .sidebar { 
        transform: translateX(-100%);
        width: 85%;
        max-width: 320px;
    }
    
    .sidebar.open { 
        transform: translateX(0);
        box-shadow: var(--shadow-lg);
    }
    
    .content { 
        margin-left: 0; 
        padding: 100px 16px 24px;
    }
    
    .mobile-toggle { 
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .categories-grid, 
    .items-grid { 
        grid-template-columns: 1fr;
        gap: 16px;
    }
    
    h1 {
        font-size: 1.8rem;
    }
    
    h2 {
        font-size: 1.4rem;
    }
    
    .category-card {
        padding: 20px;
    }
    
    .category-card .icon {
        font-size: 2.5rem;
    }
    
    .item-card img {
        height: 200px;
    }
    
    .modal-box {
        margin: 10px;
        max-height: 95vh;
    }
    
    .fact-box {
        padding: 24px 20px;
    }
    
    .fact-icon {
        font-size: 3rem;
    }
}

@media (max-width: 480px) {
    .content {
        padding: 90px 12px 20px;
    }
    
    .sidebar {
        width: 100%;
        max-width: 100%;
    }
    
    h1 {
        font-size: 1.6rem;
    }
    
    h2 {
        font-size: 1.3rem;
    }
    
    .nav-menu li {
        padding: 12px 14px;
        font-size: 0.9rem;
    }
    
    .category-card {
        padding: 18px;
    }
    
    .item-card-content {
        padding: 16px;
    }
    
    .btn-back {
        width: 100%;
        justify-content: center;
    }
    
    #yandex-map {
        height: 250px;
    }
}

/* Overlay for mobile sidebar */
.sidebar-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    backdrop-filter: blur(4px);
    z-index: 99;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.sidebar-overlay.show {
    display: block;
    opacity: 1;
}

/* Improved form elements */
input, button, select, textarea {
    font-family: inherit;
}

/* Smooth scroll for webkit */
@media screen and (-webkit-min-device-pixel-ratio: 0) {
    html {
        scroll-behavior: smooth;
    }
}

/* Print styles */
@media print {
    .sidebar,
    .mobile-toggle,
    .theme-btn,
    .btn-back {
        display: none !important;
    }
    
    .content {
        margin-left: 0;
        padding: 20px;
    }
}
</style>
</head>
<body class="dark-theme">
<button class="mobile-toggle" id="mobile-toggle">☰</button>
<div class="sidebar-overlay" id="sidebar-overlay"></div>
<div id="modal-overlay" class="modal-overlay hidden">
<div class="modal-box">
<button class="modal-close" id="modal-close">✕</button>
<div id="modal-content"></div>
</div>
</div>
<div class="app-container">
<nav class="sidebar" id="sidebar">
<div class="logo">🗺️ Путеводитель</div>
<div class="sidebar-content">
<div class="city-selector">
<label>🏙️ Город:</label>
<div class="custom-city-dropdown" id="city-dropdown">
<div class="city-search-box">
<input type="text" id="city-input" placeholder="Выберите город..." autocomplete="off" readonly>
<button class="city-toggle" id="city-toggle">▼</button>
</div>
<ul class="city-options" id="city-options"></ul>
</div>
</div>
<ul class="nav-menu">
<li data-section="home" class="active">🏠 Главная</li>
<li data-section="attractions">🔎 Достопримечательности</li>
<li data-section="news">📰 Новости</li>
<li data-section="media">🎬 Медиа</li>
<li data-section="facts">💡 Факты</li>
</ul>
<button id="theme-toggle" class="theme-btn">🌙 Тёмная тема</button>
</div>
</nav>
<main class="content">
<section id="home" class="section active">
    <h1>🖐 Добро пожаловать!</h1>
    <div class="fact-box">
        <span class="fact-icon"></span>
        <p>Выберите город в меню слева, чтобы начать путешествие</p>
    </div>
</section>
<section id="attractions" class="section">
<h2>🔎 Достопримечательности</h2>
<nav id="breadcrumbs" style="margin-bottom:10px;color:var(--text-secondary)"></nav>
<div id="root-categories" class="categories-grid"></div>
<div id="sub-categories" class="categories-grid hidden"></div>
<div id="items-list" class="items-grid hidden"></div>
<button id="back-btn" class="btn-back hidden">← Назад</button>
</section>
<section id="news" class="section"><h2>📰 Новости</h2><div id="news-list"></div></section>
<section id="media" class="section">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;flex-wrap:wrap;gap:12px">
<h2>🎬 Рекомендация</h2>
<button id="new-media-btn" style="padding:10px 20px;background:var(--bg-tertiary);color:var(--text-primary);border:2px solid var(--border);border-radius:var(--radius-md);cursor:pointer;font-weight:600;transition:var(--transition)">🔄 Другой</button>
</div>
<div id="media-card"></div>
</section>
<section id="facts" class="section">
<h2>💡 Интересные факты</h2>
<div id="fact-display" class="fact-box"><span class="fact-icon">🤔</span><p>Нажмите кнопку, чтобы узнать интересный факт!</p></div>
<button id="new-fact-btn" style="width:100%;padding:14px;background:linear-gradient(135deg, var(--accent) 0%, var(--accent-hover) 100%);color:#fff;border:none;border-radius:var(--radius-md);cursor:pointer;font-weight:600;font-size:1rem;box-shadow:0 4px 12px var(--accent-glow);transition:var(--transition)">🔄 Ещё факт</button>
</section>
</main>
</div>
<script src="app.js"></script>
<script>
// Mobile sidebar toggle
const mobileToggle = document.getElementById('mobile-toggle');
const sidebar = document.getElementById('sidebar');
const sidebarOverlay = document.getElementById('sidebar-overlay');

mobileToggle?.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    sidebarOverlay.classList.toggle('show');
});

sidebarOverlay?.addEventListener('click', () => {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('show');
});

document.addEventListener('click', e => { 
    if (!sidebar.contains(e.target) && !mobileToggle.contains(e.target) && window.innerWidth <= 768) {
        sidebar.classList.remove('open');
        sidebarOverlay.classList.remove('show');
    }
});

// Map functionality
let yandexMap = null;
function initMapForItem(lat, lon, title) {
if (yandexMap) yandexMap.destroy();
yandexMap = new ymaps.Map("yandex-map", { center: [lat, lon], zoom: 16, controls: ['zoomControl'] });
yandexMap.geoObjects.add(new ymaps.Placemark([lat, lon], { balloonContent: `<strong>${title}</strong>` }, { preset: 'islands#redIcon' }));
}

window.openModal = function(content, itemData) {
document.getElementById('modal-content').innerHTML = `<div class="modal-content">${content}</div>`;
document.getElementById('modal-overlay').classList.remove('hidden');
document.body.style.overflow = 'hidden';
if (itemData?.latitude) setTimeout(() => initMapForItem(parseFloat(itemData.latitude), parseFloat(itemData.longitude), itemData.title), 100);
};

document.getElementById('modal-close')?.addEventListener('click', () => {
    document.getElementById('modal-overlay').classList.add('hidden');
    document.body.style.overflow = '';
});

document.getElementById('modal-overlay')?.addEventListener('click', (e) => {
    if (e.target === document.getElementById('modal-overlay')) {
        document.getElementById('modal-overlay').classList.add('hidden');
        document.body.style.overflow = '';
    }
});

// City Dropdown Logic
(function() {
const input = document.getElementById('city-input');
const list = document.getElementById('city-options');
const toggle = document.getElementById('city-toggle');
const dropdown = document.getElementById('city-dropdown');
let cities = [], currentId = 1;

async function loadCities() {
try {
const res = await fetch('index.php', { method: 'POST', body: (() => { const f = new FormData(); f.append('action', 'get_cities'); return f; })() });
const json = await res.json();
if (json.success) { cities = json.data; render(cities); selectCity(1); }
} catch(e) { console.error(e); }
}

function render(data) { list.innerHTML = data.length ? data.map(c => `<li data-id="${c.id}">${c.name}</li>`).join('') : '<li style="padding:12px 16px;color:var(--text-muted)">Ничего не найдено</li>'; }

function selectCity(id) {
currentId = id;
const c = cities.find(x => x.id == id);
if (c) {
input.value = c.name;
list.querySelectorAll('li').forEach(li => li.classList.toggle('selected', li.dataset.id == id));
window.dispatchEvent(new CustomEvent('city:change', { detail: { id, slug: c.slug, name: c.name } }));
// Close sidebar on mobile after selection
if (window.innerWidth <= 768) {
    sidebar.classList.remove('open');
    sidebarOverlay.classList.remove('show');
}
}
}

toggle?.addEventListener('click', () => { list.classList.toggle('show'); input.removeAttribute('readonly'); input.focus(); });

input?.addEventListener('input', e => { render(cities.filter(c => c.name.toLowerCase().includes(e.target.value.toLowerCase()))); list.classList.add('show'); });

list?.addEventListener('click', e => { if (e.target.dataset.id) { selectCity(e.target.dataset.id); list.classList.remove('show'); input.setAttribute('readonly', true); } });

document.addEventListener('click', e => { if (!dropdown.contains(e.target)) { list.classList.remove('show'); input?.setAttribute('readonly', true); } });

loadCities();
})();

ymaps.ready(() => console.log('✅ Карты готовы'));
</script>
</body>
</html>