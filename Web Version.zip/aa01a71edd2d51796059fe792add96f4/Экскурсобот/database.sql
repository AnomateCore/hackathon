-- ============================================================
-- База данных: Белгород-Гид (Экскурсобот)
-- Полная схема + начальные данные
-- ============================================================

CREATE DATABASE IF NOT EXISTS belgorod_guide CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE belgorod_guide;

-- ============================================================
-- ТАБЛИЦЫ
-- ============================================================

-- Города (для расширяемости)
CREATE TABLE IF NOT EXISTS cities (
    id   INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(50)  UNIQUE NOT NULL
);

-- Категории достопримечательностей (двухуровневое дерево)
CREATE TABLE IF NOT EXISTS categories (
    id         INT PRIMARY KEY AUTO_INCREMENT,
    name       VARCHAR(100) NOT NULL,
    slug       VARCHAR(50)  UNIQUE NOT NULL,
    icon       VARCHAR(20)  DEFAULT '📍',
    parent_id  INT          NULL,
    sort_order INT          DEFAULT 0,
    is_active  BOOLEAN      DEFAULT TRUE,
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- Достопримечательности
CREATE TABLE IF NOT EXISTS attractions (
    id          INT PRIMARY KEY AUTO_INCREMENT,
    city_id     INT          NOT NULL DEFAULT 1,
    category_id INT          NOT NULL,
    title       VARCHAR(255) NOT NULL,
    description TEXT         NOT NULL,
    image_url   VARCHAR(500),
    latitude    DECIMAL(10,8),
    longitude   DECIMAL(11,8),
    address     VARCHAR(255),
    is_active   BOOLEAN      DEFAULT TRUE,
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (city_id)     REFERENCES cities(id)     ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- Интересные факты
CREATE TABLE IF NOT EXISTS facts (
    id         INT PRIMARY KEY AUTO_INCREMENT,
    city_id    INT     NOT NULL DEFAULT 1,
    content    TEXT    NOT NULL,
    is_active  BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (city_id) REFERENCES cities(id) ON DELETE CASCADE
);

-- Новости (кэшированные)
CREATE TABLE IF NOT EXISTS news (
    id           INT PRIMARY KEY AUTO_INCREMENT,
    city_id      INT          NOT NULL DEFAULT 1,
    title        VARCHAR(255) NOT NULL,
    content      TEXT         NOT NULL,
    image_url    VARCHAR(500),
    source_url   VARCHAR(500),
    published_at TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    cached_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (city_id) REFERENCES cities(id) ON DELETE CASCADE
);

-- Медиа-рекомендации
CREATE TABLE IF NOT EXISTS media (
    id          INT PRIMARY KEY AUTO_INCREMENT,
    title       VARCHAR(255) NOT NULL,
    description TEXT,
    poster_url  VARCHAR(500),
    link_url    VARCHAR(500),
    rating      DECIMAL(3,1),
    is_active   BOOLEAN DEFAULT TRUE
);

-- ============================================================
-- ИНДЕКСЫ
-- ============================================================
CREATE INDEX idx_attractions_category ON attractions(category_id, is_active);
CREATE INDEX idx_attractions_city     ON attractions(city_id, is_active);
CREATE INDEX idx_news_city_cached     ON news(city_id, cached_at);
CREATE INDEX idx_facts_city           ON facts(city_id, is_active);

-- ============================================================
-- ГОРОДА
-- ============================================================
INSERT INTO cities (name, slug) VALUES
('Белгород', 'belgorod');

-- ============================================================
-- КАТЕГОРИИ (двухуровневое дерево)
-- Уровень 1: корневые разделы
-- Уровень 2: подкатегории
-- ============================================================
INSERT INTO categories (id, name, slug, icon, parent_id, sort_order) VALUES
-- Корневые
(1,  'Достопримечательности', 'attractions',   '🔎', NULL, 1),
(6,  'Развлекательные объекты','entertainment', '🎤', NULL, 2),

-- Подкатегории Достопримечательностей
(2,  'Церкви и соборы',        'churches',      '⛪', 1, 1),
(3,  'Культурные объекты',     'cultural',      '⛲', 1, 2),
(4,  'Исторические объекты',   'historical',    '📚', 1, 3),
(5,  'Парки',                  'parks',         '🏝', 1, 4),

-- Подкатегории Развлекательных объектов
(7,  'Активный отдых',         'active',        '🚴', 6, 1),
(8,  'Кафе и рестораны',       'cafes',         '🍸', 6, 2),
(9,  'Детские центры',         'kids',          '👼', 6, 3),
(10, 'VR и компьютерные клубы','vr',            '🎮', 6, 4);

-- ============================================================
-- ЦЕРКВИ И СОБОРЫ (category_id = 2)
-- ============================================================
INSERT INTO attractions (city_id, category_id, title, description, image_url, latitude, longitude, address) VALUES
(1, 2, 'Свято-Троицкий кафедральный собор',
 'Главный православный храм Белгорода, построенный в 1813 году в стиле классицизма. Здесь хранится чудотворная икона Божией Матери «Избавительница». Собор является архитектурной доминантой центра города.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8c/Belgorod_Cathedral.jpg/800px-Belgorod_Cathedral.jpg',
 50.59840600, 36.58851700, 'ул. Соборная, 1'),

(1, 2, 'Смоленский собор',
 'Один из старейших храмов Белгорода, основан в 1756 году. Уникальный образец барокко с богатой фресковой росписью. В соборе покоятся мощи святителя Иоасафа Белгородского.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Smolensky_Cathedral_Belgorod.jpg/800px-Smolensky_Cathedral_Belgorod.jpg',
 50.59538300, 36.59491300, 'ул. Чичерина, 14'),

(1, 2, 'Храм Великомученика Георгия Победоносца',
 'Современный храм, освящённый в 2012 году. Построен в память о воинах, погибших в локальных конфликтах. Отличается величественной архитектурой и уютной территорией.',
 'https://beleparh.ru/images/hrams/georgiy.jpg',
 50.61245000, 36.60123000, 'ул. Губкина, 18'),

(1, 2, 'Николо-Иоасафовский собор',
 'Восстановленный собор на месте древнего монастыря. Назван в честь святителя Иоасафа — небесного покровителя Белгородской земли. Внутри — уникальные иконостасы и росписи.',
 'https://beleparh.ru/images/hrams/nikolo-ioasaf.jpg',
 50.59712000, 36.59045000, 'ул. Чичерина, 22'),

(1, 2, 'Храм Почаевской иконы Божией Матери',
 'Небольшой уютный храм в микрорайоне Новый. Известен своими благотворительными программами и молодёжным приходом. Регулярно проводятся концерты духовной музыки.',
 'https://beleparh.ru/images/hrams/pochaev.jpg',
 50.62580000, 36.61540000, 'ул. Щорса, 45');

-- ============================================================
-- КУЛЬТУРНЫЕ ОБЪЕКТЫ (category_id = 3)
-- ============================================================
INSERT INTO attractions (city_id, category_id, title, description, image_url, latitude, longitude, address) VALUES
(1, 3, 'Белгородский государственный драматический театр им. М.С. Щепкина',
 'Старейший театр региона, основан в 1936 году. Репертуар включает классику и современные постановки. Здание театра — памятник архитектуры сталинского ампира.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Belgorod_Drama_Theatre.jpg/800px-Belgorod_Drama_Theatre.jpg',
 50.59920000, 36.59180000, 'ул. Щепкина, 3'),

(1, 3, 'Белгородский художественный музей',
 'Коллекция из более чем 10 000 экспонатов: русская живопись, иконы, скульптура, декоративно-прикладное искусство. Регулярные выставки современных художников.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Belgorod_Art_Museum.jpg/800px-Belgorod_Art_Museum.jpg',
 50.60150000, 36.58930000, 'пр. Славы, 15'),

(1, 3, 'Белгородская государственная филармония',
 'Концертная площадка с отличным акустическим залом. Здесь выступают симфонические оркестры, фольклорные ансамбли и приглашённые звёзды.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Belgorod_Philharmonic.jpg/800px-Belgorod_Philharmonic.jpg',
 50.59890000, 36.59320000, 'ул. Щорса, 23'),

(1, 3, 'Музей-диорама «Курская битва»',
 'Уникальная экспозиция, посвящённая Прохоровскому сражению. Включает диораму площадью 1000 м², военную технику и личные вещи участников битвы.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Belgorod_Diorama.jpg/800px-Belgorod_Diorama.jpg',
 50.60340000, 36.58760000, 'пр. Богдана Хмельницкого, 83в'),

(1, 3, 'Литературный музей',
 'Посвящён писателям Белгородчины. Интерактивные экспозиции и литературные вечера.',
 'https://belgorod-museum.ru/images/lit-museum.jpg',
 50.60010000, 36.59050000, 'ул. Попова, 2');

-- ============================================================
-- ИСТОРИЧЕСКИЕ ОБЪЕКТЫ (category_id = 4)
-- ============================================================
INSERT INTO attractions (city_id, category_id, title, description, image_url, latitude, longitude, address) VALUES
(1, 4, 'Белгородская крепость',
 'Историко-археологический комплекс на месте древней крепости, основанной в 1596 году. Реконструированные стены, башни и музей под открытым небом.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Belgorod_Fortress.jpg/800px-Belgorod_Fortress.jpg',
 50.59670000, 36.59210000, 'ул. Крепостная, 1'),

(1, 4, 'Памятник князю Владимиру',
 'Монументальная скульптура высотой 18 метров, установленная в 2015 году. Символизирует крещение Руси и духовные истоки Белгородской земли.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Vladimir_Monument_Belgorod.jpg/800px-Vladimir_Monument_Belgorod.jpg',
 50.59780000, 36.58990000, 'Соборная площадь'),

(1, 4, 'Мемориал «Вечный огонь»',
 'Мемориальный комплекс в честь героев Великой Отечественной войны. Вечный огонь зажжён в 1967 году. Место проведения памятных церемоний.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Belgorod_Eternal_Flame.jpg/800px-Belgorod_Eternal_Flame.jpg',
 50.60120000, 36.58840000, 'парк Победы'),

(1, 4, 'Дом воеводы',
 'Реконструкция деревянного дома воеводы Белгородской крепости XVII века. Внутри — экспозиция о быте и службе защитников южных рубежей России.',
 'https://belgorod-museum.ru/images/voevoda-house.jpg',
 50.59690000, 36.59230000, 'ул. Крепостная, 3'),

(1, 4, 'Стела «Город воинской славы»',
 'Установлена в 2007 году в честь присвоения Белгороду почётного звания. На гранитных плитах — хроники боевых подвигов жителей города.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Belgorod_Military_Glory_Stele.jpg/800px-Belgorod_Military_Glory_Stele.jpg',
 50.59810000, 36.59020000, 'Соборная площадь');

-- ============================================================
-- ПАРКИ (category_id = 5)
-- ============================================================
INSERT INTO attractions (city_id, category_id, title, description, image_url, latitude, longitude, address) VALUES
(1, 5, 'Парк Победы',
 'Крупнейший парк города площадью 120 га. Аллеи славы, озёра, велодорожки, детские площадки. Место проведения городских праздников и фестивалей.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Belgorod_Victory_Park.jpg/800px-Belgorod_Victory_Park.jpg',
 50.60250000, 36.58700000, 'пр. Богдана Хмельницкого'),

(1, 5, 'Центральный парк культуры и отдыха',
 'Исторический парк в центре города. Аттракционы, летняя эстрада, кафе, прокат лодок. Зимой — каток и ледяные горки.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Belgorod_Central_Park.jpg/800px-Belgorod_Central_Park.jpg',
 50.60080000, 36.59450000, 'ул. Горького, 12'),

(1, 5, 'Ботанический сад БГУ',
 'Учебно-научный комплекс с коллекцией из 1500 видов растений. Оранжереи, розарий, дендрарий. Проводятся экскурсии и мастер-классы.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/BSU_Botanical_Garden.jpg/800px-BSU_Botanical_Garden.jpg',
 50.61520000, 36.60890000, 'ул. Студенческая, 14'),

(1, 5, 'Набережная реки Везёлки',
 'Благоустроенная пешеходная зона вдоль реки. Скамейки, фонари, арт-объекты, точки проката самокатов. Популярное место для вечерних прогулок.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/v/ve/Vezyolka_Embankment.jpg/800px-Vezyolka_Embankment.jpg',
 50.59950000, 36.59620000, 'наб. реки Везёлки'),

(1, 5, 'Парк «Лески»',
 'Природный парк на окраине города с хвойными и лиственными лесами. Экологические тропы, зоны для пикников, наблюдение за птицами.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/l/le/Leski_Park_Belgorod.jpg/800px-Leski_Park_Belgorod.jpg',
 50.57890000, 36.56540000, 'ул. Лесная, 45');

-- ============================================================
-- АКТИВНЫЙ ОТДЫХ (category_id = 7)
-- ============================================================
INSERT INTO attractions (city_id, category_id, title, description, image_url, latitude, longitude, address) VALUES
(1, 7, 'Вейк-парк «Белгород»',
 'Современный комплекс для вейкбординга и кайтсёрфинга. Два канатных трамплина, прокат оборудования, школа для новичков.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/w/we/Belgorod_Wakepark.jpg/800px-Belgorod_Wakepark.jpg',
 50.56520000, 36.54210000, 'Белгородское водохранилище'),

(1, 7, 'Верёвочный парк «Маугли»',
 'Приключенческий парк с трассами разной сложности для детей и взрослых. Зиплайн, тарзанки, скалодром. Инструкторы и страховка включены.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/m/me/Maugli_Rope_Park.jpg/800px-Maugli_Rope_Park.jpg',
 50.60380000, 36.58560000, 'парк Победы'),

(1, 7, 'Велопрокат «ВелоБел»',
 'Сеть пунктов проката велосипедов и электросамокатов. Маршруты по городу, карты достопримечательностей, ремонт в пути.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/v/vb/VeloBel_Belgorod.jpg/800px-VeloBel_Belgorod.jpg',
 50.60000000, 36.59000000, 'несколько точек в центре'),

(1, 7, 'Скалодром «Высота»',
 'Крытый скалодром с трассами от начального до экспертного уровня. Групповые занятия, детские секции, соревнования.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/h/he/Vysota_Climbing_Wall.jpg/800px-Vysota_Climbing_Wall.jpg',
 50.61230000, 36.60540000, 'ул. Королёва, 12'),

(1, 7, 'Лодочная станция «Везёлка»',
 'Прокат лодок, катамаранов и байдарок. Маршруты по реке Везёлке, рыболовные туры, обучение гребле.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Vezyolka_Boat_Station.jpg/800px-Vezyolka_Boat_Station.jpg',
 50.59870000, 36.59780000, 'наб. реки Везёлки, 8');

-- ============================================================
-- КАФЕ И РЕСТОРАНЫ (category_id = 8)
-- ============================================================
INSERT INTO attractions (city_id, category_id, title, description, image_url, latitude, longitude, address) VALUES
(1, 8, 'Ресторан «Белгородский подворье»',
 'Традиционная русская кухня в атмосфере старинной усадьбы. Живая музыка по выходным, банкетный зал, летняя веранда.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/p/pe/Podvorie_Restaurant.jpg/800px-Podvorie_Restaurant.jpg',
 50.59980000, 36.59120000, 'ул. Щепкина, 7'),

(1, 8, 'Кофейня «Уголок»',
 'Уютная кофейня с авторским кофе, домашней выпечкой и настольными играми. Бесплатный Wi-Fi, розетки, тихая музыка.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/u/ue/Ugolok_Cafe.jpg/800px-Ugolok_Cafe.jpg',
 50.60110000, 36.58970000, 'пр. Славы, 22'),

(1, 8, 'Пиццерия «Итальянский дворик»',
 'Семейная пиццерия с тестом собственного приготовления. Детское меню, игровая зона, доставка по городу.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/i/ie/Italian_Yard_Pizzeria.jpg/800px-Italian_Yard_Pizzeria.jpg',
 50.60280000, 36.59340000, 'ул. Губкина, 35'),

(1, 8, 'Бар «Хмель & Солод»',
 'Крафтовый бар с коллекцией из 50+ сортов пива от локальных пивоварен. Закуски, квизы по пятницам, трансляции спортивных событий.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/h/he/Hops_Malt_Bar.jpg/800px-Hops_Malt_Bar.jpg',
 50.60050000, 36.59280000, 'ул. Чичерина, 28'),

(1, 8, 'Кафе «Завтрак-клуб»',
 'Кафе с завтраками весь день: сырники, омлеты, блинчики, смузи. Веганские опции, детский уголок, быстрый сервис.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Breakfast_Club_Cafe.jpg/800px-Breakfast_Club_Cafe.jpg',
 50.59820000, 36.59080000, 'ул. Попова, 15');

-- ============================================================
-- ДЕТСКИЕ ЦЕНТРЫ (category_id = 9)
-- ============================================================
INSERT INTO attractions (city_id, category_id, title, description, image_url, latitude, longitude, address) VALUES
(1, 9, 'Детский развлекательный центр «Лукоморье»',
 'Большой игровой комплекс с лабиринтами, батутами, сухим бассейном. Аниматоры, дни рождения, безопасные зоны для малышей.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/l/le/Lukomorie_Kids_Center.jpg/800px-Lukomorie_Kids_Center.jpg',
 50.60520000, 36.59810000, 'ТЦ «МегаГРИНН», 2 этаж'),

(1, 9, 'Парк аттракционов «Сказка»',
 'Классический парк с каруселями, автодромом, комнатой смеха. Сезонные мероприятия: новогодние ёлки, летние фестивали.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/s/se/Skazka_Park_Belgorod.jpg/800px-Skazka_Park_Belgorod.jpg',
 50.60150000, 36.59520000, 'Центральный парк'),

(1, 9, 'Научное шоу «Эврика»',
 'Интерактивный центр с опытами по физике и химии. Программы для школьников, мастер-классы, мобильное приложение с дополненной реальностью.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/Evrika_Science_Show.jpg/800px-Evrika_Science_Show.jpg',
 50.61340000, 36.60780000, 'ул. Студенческая, 20'),

(1, 9, 'Детская железная дорога',
 'Малая железная дорога протяжённостью 2 км. Поезда управляются юными железнодорожниками. Экскурсии, фотосессии, тематические рейсы.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/k/ke/Kids_Railway_Belgorod.jpg/800px-Kids_Railway_Belgorod.jpg',
 50.58560000, 36.57890000, 'парк «Лески»'),

(1, 9, 'Игровой центр «Лимпопо»',
 'Современный центр с лабиринтами, горками, зоной для родителей. Кафе с детским меню, услуги няни, бесплатный гардероб.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/l/le/Limpopo_Kids_Center.jpg/800px-Limpopo_Kids_Center.jpg',
 50.60890000, 36.60120000, 'ТЦ «Славянский», 3 этаж');

-- ============================================================
-- VR И КОМПЬЮТЕРНЫЕ КЛУБЫ (category_id = 10)
-- ============================================================
INSERT INTO attractions (city_id, category_id, title, description, image_url, latitude, longitude, address) VALUES
(1, 10, 'VR-арена «Киберполигон»',
 'Командные игры в виртуальной реальности на площади 200 м². Сценарии: зомби-апокалипсис, космические битвы, квесты. Оборудование премиум-класса.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Cyber_Polygon_VR.jpg/800px-Cyber_Polygon_VR.jpg',
 50.60450000, 36.59670000, 'ул. Щорса, 52'),

(1, 10, 'Компьютерный клуб «Арена»',
 'Современный киберспортивный клуб с мощными ПК, механическими клавиатурами и профессиональными мониторами. Турниры, стриминг-зоны, бар.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ae/Arena_Computer_Club.jpg/800px-Arena_Computer_Club.jpg',
 50.60210000, 36.59430000, 'пр. Богдана Хмельницкого, 45'),

(1, 10, 'Квест в виртуальной реальности «Портал»',
 'Индивидуальные и командные квесты с полным погружением. Темы: детектив, фэнтези, хоррор. Системы отслеживания движений и тактильная обратная связь.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/p/pe/Portal_VR_Quest.jpg/800px-Portal_VR_Quest.jpg',
 50.59990000, 36.59150000, 'ул. Чичерина, 33'),

(1, 10, 'VR-кафе «Нейро»',
 'Уютное кафе с зонами виртуальной реальности. Можно совместить кофе с игрой в ритм-игры, симуляторы полёта или творческие приложения.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/n/ne/Neuro_VR_Cafe.jpg/800px-Neuro_VR_Cafe.jpg',
 50.60180000, 36.59210000, 'ул. Горького, 18'),

(1, 10, 'Лаборатория роботов «ТехноДети»',
 'Образовательно-развлекательный центр: программирование роботов, 3D-печать, курсы по VR-разработке для детей и подростков.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/t/te/TechnoKids_Lab.jpg/800px-TechnoKids_Lab.jpg',
 50.61420000, 36.60950000, 'ул. Студенческая, 25');

-- ============================================================
-- ИНТЕРЕСНЫЕ ФАКТЫ
-- ============================================================
INSERT INTO facts (city_id, content) VALUES
(1, 'Белгород — первый город России, получивший звание «Город воинской славы» в 2007 году.'),
(1, 'В Белгороде находится самый большой в мире памятник князю Владимиру высотой 18 метров.'),
(1, 'Белгородская область — лидер России по производству сахара и подсолнечного масла.'),
(1, 'В Белгородском государственном университете обучается более 30 000 студентов из 50 стран мира.'),
(1, 'Под Белгородом в 1943 году произошло крупнейшее танковое сражение в истории — Прохоровское.'),
(1, 'Белгородский драматический театр носит имя великого русского актёра Михаила Щепкина, родившегося в Курской губернии.'),
(1, 'В Белгороде работает единственный в Черноземье планетарий с цифровым куполом.'),
(1, 'Река Везёлка, протекающая через Белгород, дала название одному из старейших районов города.'),
(1, 'Белгородский художественный музей хранит подлинную икону «Богоматерь Белгородская» XVII века.'),
(1, 'В 2020 году Белгород вошёл в топ-10 самых благоустроенных городов России по версии Минстроя.');

-- ============================================================
-- НОВОСТИ
-- ============================================================
INSERT INTO news (city_id, title, content, image_url, source_url) VALUES
(1, 'Хирурги Старого Оскола освоили операции по замене тазобедренного сустава',
 'Средства на оборудование и инструменты были выделены из бюджета Белгородской области. Теперь пациенты могут получать высокотехнологичную помощь без выезда в другие регионы.',
 'https://s11.stc.yc.kpcdn.net/share/i/12/13513178/wr-750.webp',
 'https://www.bel.kp.ru/'),

(1, 'В Белгороде открылся новый культурный сезон',
 'Филармония, драмтеатр и музеи представили программы на осень-зиму. Впервые пройдёт фестиваль уличных театров «Город играет».',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Belgorod_Drama_Theatre.jpg/800px-Belgorod_Drama_Theatre.jpg',
 'https://www.bel.ru/'),

(1, 'Парк Победы получил грант на обновление',
 'На средства гранта будут отремонтированы аллеи, установлено новое освещение и организована зона для воркаута.',
 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Belgorod_Victory_Park.jpg/800px-Belgorod_Victory_Park.jpg',
 'https://www.bel.ru/');

-- ============================================================
-- МЕДИА-РЕКОМЕНДАЦИИ
-- ============================================================
INSERT INTO media (title, description, poster_url, link_url, rating) VALUES
('Кибердеревня',
 'Марсианский фермер защищает своё хозяйство от алчной корпорации. Обаятельная сай-фай-комедия с элементами социальной сатиры.',
 'https://www.film.ru/sites/default/files/styles/thumb_260x400/public/movies/posters/50620410-2629051.jpg',
 'https://www.kinopoisk.ru/film/5005478/', 8.5),

('Слово пацана. Кровь на асфальте',
 'Драма о молодёжи Казани конца 1980-х. Жёсткая, но честная история о выборе, дружбе и взрослении.',
 'https://avatars.mds.yandex.net/get-kinopoisk-image/1900788/b4e3e3e3-e3e3-4e3e-b3e3-e3e3e3e3e3e3/orig',
 'https://www.kinopoisk.ru/film/5042933/', 9.1),

('Мастер и Маргарита (2024)',
 'Новая экранизация бессмертного романа Булгакова с масштабными декорациями и звёздным составом.',
 'https://avatars.mds.yandex.net/get-kinopoisk-image/1900788/a3a3a3a3-a3a3-4a3a-b3a3-a3a3a3a3a3a3/orig',
 'https://www.kinopoisk.ru/film/5233504/', 8.8);
