<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'j919433u_1');
define('DB_USER', 'j919433u_1');
define('DB_PASS', 'j919433u_1@localhost');
define('DB_CHARSET', 'utf8mb4');

function getPDO() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'DB Error']);
            exit;
        }
    }
    return $pdo;
}
?>